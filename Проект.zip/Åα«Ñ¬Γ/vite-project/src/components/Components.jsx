export default function Components({ course }) {
  return (
    <div style={{ border: "1px solid gray", margin: "10px", padding: "10px" }}>
      <h3>{course.title}</h3>
      <button>Подробнее</button>
    </div>
  );
}