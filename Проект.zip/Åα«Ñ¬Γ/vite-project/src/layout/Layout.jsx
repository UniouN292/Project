import { Outlet, Link } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Layout() {
  const { user, logout } = useContext(AuthContext);

  return (
    <div style={{ fontFamily: "sans-serif", padding: "20px" }}>
      <header style={{ marginBottom: "20px" }}>
        <h1>Онлайн-курсы</h1>
        <nav>
          <Link to="/" style={{ marginRight: "10px" }}>Home</Link>
          <Link to="/courses" style={{ marginRight: "10px" }}>Courses</Link>
          <Link to="/about" style={{ marginRight: "10px" }}>About</Link>
          {!user && <Link to="/login" style={{ marginRight: "10px" }}>Login</Link>}
          {!user && <Link to="/register" style={{ marginRight: "10px" }}>Register</Link>}
          {user && <Link to="/dashboard" style={{ marginRight: "10px" }}>Dashboard</Link>}
          {user && <button onClick={logout}>Logout</button>}
        </nav>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  );
}