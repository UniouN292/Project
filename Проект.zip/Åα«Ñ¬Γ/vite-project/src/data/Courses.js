const Courses = [
  {
    id: 1,
    title: "React для начинающих",
    price: 100
  },
  {
    id: 2,
    title: "JavaScript Pro",
    price: 150
  },
  {
    id: 3,
    title: "UI/UX Design",
    price: 120
  }
];

export default Courses;