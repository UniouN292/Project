export default function Courses() {
  const courses = [
    { name: "React", level: "Средний", img: "https://icon.icepanel.io/Technology/svg/React.svg" },
    { name: "Vite", level: "Начальный", img: "https://icon.icepanel.io/Technology/svg/Vite.js.svg" },
    { name: "JavaScript", level: "Для всех уровней", img: "https://icon.icepanel.io/Technology/svg/JavaScript.svg" },
    { name: "CSS", level: "Начальный", img: "https://icon.icepanel.io/Technology/svg/CSS3.svg" },
  ];

  return (
    <div>
      <h2>Список курсов</h2>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {courses.map((course, i) => (
          <div key={i} className="course-card">
            <img 
              src={course.img} 
              alt={course.name} 
              style={{ width: "150px", height: "150px", objectFit: "cover", marginBottom: "10px" }}
            />
            <h3>{course.name}</h3>
            <p>Уровень: {course.level}</p>
            <button>Начать</button>
          </div>
        ))}
      </div>
    </div>
  );
}