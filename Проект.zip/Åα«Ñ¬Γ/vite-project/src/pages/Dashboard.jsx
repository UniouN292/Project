import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function Dashboard() {
  const { user } = useContext(AuthContext);

  if (!user) return <Navigate to="/login" />;

  return (
    <div>
      <h2>Добро Пожаловать, {user.username}!</h2>
      <p>Это твой дэшборд.</p>
    </div>
  );
}